<?php
 require_once 'configuration.php';
  $response = array();
 if($_POST['id']){
	 $id = $_POST['id'];
	 $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
	 $stmt->bind_param("s",$id);
	 if($stmt->execute()){
		 $response['error'] = false;
		 $response['message'] = "Producto Borrado Correctamente!";
	 } else{
		 $response['error'] = true;
		 $response['message'] = "Fallo Al Borrar Producto!";
	 }
 } else{
	 $response['error'] = true;
	 $response['message'] = "Datos Insuficientes";
 }
 echo json_encode($response);
?>