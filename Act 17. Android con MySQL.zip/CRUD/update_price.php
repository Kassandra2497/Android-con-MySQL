<?php
 require_once 'configuration.php';
  $response = array();
 
 if($_POST['id'] && $_POST['price']){
	 $id = $_POST['id'];
	 $price = $_POST['price'];
	 $stmt = $conn->prepare("UPDATE products SET price = ? WHERE id = ?");
	 $stmt->bind_param("ss",$price, $id);
	 if($stmt->execute() == TRUE){
		 $response['error'] = false;
		 $response['message'] = "Precio Actualizado Correctamente!";
	 } else{
		 $response['error'] = true;
		 $response['message'] = "ID Incorrecta";
	 }
 } else{
	 $response['error'] = true;
	 $response['message'] = "Parametros Insuficientes";
 }
 echo json_encode($response);
?>