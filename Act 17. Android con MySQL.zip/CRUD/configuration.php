<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cursoandroid";
$conn = new mysqli($servername, $username, $password, $dbname);
?>